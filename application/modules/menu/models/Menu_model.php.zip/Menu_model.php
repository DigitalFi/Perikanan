<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Menu_model extends CI_Model{
	
	function __construct(){
			  // Call the Model constructor
		parent::__construct();
	   $this->load->library('session');
       $this->load->database();
       $this->load->helper('common');
	}	


	function get_detail($id_content){
		$blog='';
		$sql ="SELECT fe_content_id, fe_img_files, fe_content_title, fe_full_content, fe_content_short_desc, fe_section_name,  
		 create_by, create_date FROM sys_fe_content WHERE status_active = 'Y'  AND fe_content_id='$id_content' ORDER BY fe_content_sort_order DESC  limit 0,1";
		$query=$this->db->query($sql);
		$row=$query->row();
		if(isset($row)){
			$img_url = base_url(). 'assets/images/upload/'.$row->fe_img_files;
			$blog.='<section id="blog" style="padding-top:2px;">
				<div class="container">';
			$blog.='<div class="row">';	
			$blog.='<div class="col-md-8">
						<h3 class="section-title text-left wow fadeInDown">'.$row->fe_content_title.'</h3>	
						<div class="entry-date">'.indonesian_date($row->create_date).'</div>
						<div class="blog-post blog-large wow fadeInLeft" data-wow-duration="300ms" data-wow-delay="0ms">
							<article>
								<header class="entry-header">
									<div class="entry-thumbnail">
										<img class="img-responsive" style="width:100%;" src="'.$img_url.'" alt="">
									</div>
									
								</header>
		
								<div class="entry-content text-justify">
									'. html_entity_decode($row->fe_full_content).'
								</div>
		
								<footer class="entry-meta">
									<span class="entry-author"><i class="fa fa-pencil"></i> <a href="#">'.$row->create_by.'</a></span>
									<span class="entry-comments"><i class="fa fa-comments-o"></i> <a href="blog/detil/'.$row->fe_content_id.'">15</a></span>
								</footer>
							</article>
						</div>
					</div><!--/.col-sm-6-->';
		
		}			
		
		return $blog;				

	}

	
}
?>